module.exports = {
  email: "amin4udin+klmsdasd@gmail.com",
  token:
    "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI1NDkxN2I5YTljMjM2ZDFhN2U2NTUzMDhiNjViYjg0ZTdkZmJjYTUxIiwiZW1haWwiOiJvcmFuZy5naWxhLmphaGEudEBnbWFpbC5jb20iLCJpc3MiOiJodHRwczovL2FwaS5iaWd0b2tlbi5jb20iLCJpYXQiOjE1NTQ5ODI1NzEsImV4cCI6MTU1NDk4NjE3MSwibmJmIjoxNTU0OTgyNTcxLCJqdGkiOiJHaVF3RG5WT0lXbGxCNFl3IiwicmVmZXJyYWxfY29kZSI6IjFaT1oxOTlNOSJ9.sO0Rn3cAE2lEzBzcfA1P0R7pXLWaIZhbxmUm5OEHRQU",
  Reff: "AMIN4UDIN",
  url: "https://gobigtoken.page.link/8qVAR1mbDh6rE1Jd9",
  headers: {
    "x-api-key": "SGB-00f2b8b718"
  }
};
